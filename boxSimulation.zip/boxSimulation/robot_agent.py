import random
from sensor_module import SensorModule

class ResponseAgent:
    """Robot implementing ResponseAgent role + A* path following + idle-unblock."""

    def __init__(self, id_):
        self.id = id_
        self.row = None
        self.col = None
        self.carrying = False
        self.assigned_task = None  
        self.path = None          
        self.path_step = 0
        self.moves = 0
        self.sensor = SensorModule(self)

    def make_proposal(self, task_pos, warehouse):
            """
            Propose using distance to the nearest reachable adjacent cell to task_pos.
            Returns None if unreachable.
            """
            path, approach = warehouse.find_reachable_adjacent((self.row, self.col), task_pos)
            if path is None:
                return None
            available = (not self.carrying) and (self.assigned_task is None)
            return {'agent_id': self.id, 'distance': len(path)-1, 'available': available, 'approach': approach}

    def assign_task(self, task_type, target_pos, warehouse, approach_pos=None):
        """
        task_type: 'pickup' or 'deliver'
        For pickup: target_pos is box_pos; approach_pos is adjacent cell we must go to.
        For deliver: target_pos is storage cell (we can go to adjacency of storage or the storage cell).
        """
        if task_type == 'pickup':
           
            self.assigned_task = ('pickup', target_pos, approach_pos)
         
            self.path = warehouse.astar((self.row, self.col), approach_pos)
            self.path_step = 0
        else:
           
            path, approach = warehouse.find_reachable_adjacent((self.row, self.col), target_pos)
            if path is None:
               
                self.path = warehouse.astar((self.row, self.col), target_pos)
                self.assigned_task = ('deliver', target_pos, target_pos)
                self.path_step = 0
            else:
                self.assigned_task = ('deliver', target_pos, approach)
                self.path = path
                self.path_step = 0

    def relocate_if_blocking(self, warehouse):
        """If robot idle and on/adjacent to storage, try to move away to free access."""
  
        if warehouse.cells[self.row][self.col].is_storage:
            self._move_to_safe_spot(warehouse)
            return
      
        for (sr, sc) in warehouse.storage_positions:
            if abs(self.row - sr) + abs(self.col - sc) == 1:
                self._move_to_safe_spot(warehouse)
                return

    def _move_to_safe_spot(self, warehouse):
        neighbors = [(1,0),(-1,0),(0,1),(0,-1)]
        random.shuffle(neighbors)
        for dr, dc in neighbors:
            nr, nc = self.row + dr, self.col + dc
            if warehouse.in_bounds(nr, nc) and warehouse.cells[nr][nc].robot is None and not warehouse.cells[nr][nc].is_storage:
                warehouse.move_robot(self, nr, nc)
                return

    def step(self, warehouse, log_fn=None):
      
        if self.assigned_task is None:
            if not self.carrying:
                self.relocate_if_blocking(warehouse)
            return

      
        t = self.assigned_task
        task_type = t[0]
        if task_type == 'pickup':
            box_pos = t[1]
            approach = t[2]
       
            if self.path is None:
                self.path, _ = warehouse.find_reachable_adjacent((self.row, self.col), box_pos)
                self.path_step = 0
               
                if self.path is None:
                 
                    br, bc = box_pos
                    if getattr(warehouse.cells[br][bc], 'reserved_by', None) == self.id:
                        warehouse.cells[br][bc].reserved_by = None
                    self.assigned_task = None
                    return

           
            if self.path_step + 1 < len(self.path):
                nr, nc = self.path[self.path_step + 1]
                moved = warehouse.move_robot(self, nr, nc)
                if moved:
                    self.path_step += 1
                    self.moves += 1
                else:
                    
                    self.path = None
                return

      
            br, bc = box_pos
            if abs(br - self.row) + abs(bc - self.col) <= 1:
                popped = warehouse.cells[br][bc].pop_box(1)
                if popped > 0:
                
                    warehouse.cells[br][bc].reserved_by = None
                    self.carrying = True
                    self.assigned_task = None
                    self.path = None
                    if log_fn:
                        log_fn(f"[Robot {self.id}] picked up at {(br,bc)}")
                else:
                    
                    warehouse.cells[br][bc].reserved_by = None
                    self.assigned_task = None
                    self.path = None
            else:
               
                self.path = None
            return

        elif task_type == 'deliver':
            storage_pos = t[1]
            approach = t[2]
            if self.path is None:
                self.path = warehouse.astar((self.row, self.col), approach)
                self.path_step = 0
                if self.path is None:
                    self.assigned_task = None
                    return
            if self.path_step + 1 < len(self.path):
                nr, nc = self.path[self.path_step + 1]
                moved = warehouse.move_robot(self, nr, nc)
                if moved:
                    self.path_step += 1
                    self.moves += 1
                else:
                    self.path = None
                return
            sr, sc = storage_pos
            if abs(sr - self.row) + abs(sc - self.col) <= 1:
                pushed = warehouse.cells[sr][sc].push_box(1)
                if pushed > 0:
                    self.carrying = False
                    self.assigned_task = None
                    self.path = None
                    if log_fn:
                        log_fn(f"[Robot {self.id}] delivered to {(sr,sc)} (now {warehouse.cells[sr][sc].stack_height()})")
                else:
                    self.assigned_task = None
                    self.path = None
            else:
                self.path = None
            return