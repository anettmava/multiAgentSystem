from cell_reading import CellReading

DIRECTIONS = {
    'UP': (-1, 0),
    'DOWN': (1, 0),
    'LEFT': (0, -1),
    'RIGHT': (0, 1)
}

class SensorModule:
    """Simplified sensor (option 2B): reads only the 4-adjacent cells."""

    def __init__(self, robot):
        self.robot = robot
        self.readings = {}

    def scanEnvironment(self, warehouse):
        self.readings.clear()
        r0, c0 = self.robot.row, self.robot.col
        for dname, (dr, dc) in DIRECTIONS.items():
            rr, cc = r0 + dr, c0 + dc
            if not warehouse.in_bounds(rr, cc):
                cr = CellReading(isWall=True, robotPresent=False, stackHeight=0, isFree=False)
            else:
                cell = warehouse.cells[rr][cc]
                cr = CellReading(
                    isWall=False,
                    robotPresent=(cell.robot is not None),
                    stackHeight=cell.stack_height(),
                    isFree=(cell.robot is None and not cell.hasStack() and not cell.is_storage)
                )
            self.readings[dname] = cr
        return self.readings

    def detectWalls(self):
        return {d: r.isWall for d, r in self.readings.items()}

    def detectStacks(self):
        return {d: r.stackHeight for d, r in self.readings.items()}

    def detectRobots(self):
        return {d: r.robotPresent for d, r in self.readings.items()}

    def detectFreeCells(self):
        return {d: r.isFree for d, r in self.readings.items()}
