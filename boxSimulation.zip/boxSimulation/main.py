import tkinter as tk
from simulation import Simulation
from ui import WarehouseUI

def compute_storage_positions(rows, cols, num_storage):
    total = rows * cols
    positions = []
    for i in range(num_storage):
        idx = int(((i + 1) * (total)) / (num_storage + 1))
        rr = idx // cols; cc = idx % cols
        positions.append((rr, cc))
    seen = set(); uniq=[]
    cur=0
    for p in positions:
        if p not in seen:
            seen.add(p); uniq.append(p)
    while len(uniq) < num_storage:
        rr = cur // cols; cc = cur % cols
        if (rr,cc) not in seen:
            seen.add((rr,cc)); uniq.append((rr,cc))
        cur += 1
    return uniq

def main():
    ROWS = 15; COLS = 18; NUM_BOXES = 50; NUM_ROBOTS = 5
    if NUM_BOXES % 5 != 0:
        NUM_BOXES = (NUM_BOXES // 5) * 5
    num_storage = NUM_BOXES // 5
    storage_positions = compute_storage_positions(ROWS, COLS, num_storage)

    sim = Simulation(width=COLS, height=ROWS, num_boxes=NUM_BOXES, num_robots=NUM_ROBOTS, storage_positions=storage_positions, log_fn=None)
    root = tk.Tk()
    ui = WarehouseUI(root, sim)
    root.mainloop()

if __name__ == "__main__":
    main()
