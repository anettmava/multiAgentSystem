class MonitoringAgent:

    def __init__(self, warehouse, log_fn=None):
        self.wh = warehouse
        self.log = log_fn or (lambda s: None)

    def find_open_boxes(self):
        boxes = []
        for r in range(self.wh.height):
            for c in range(self.wh.width):
                cell = self.wh.cells[r][c]
                if cell.hasStack() and not cell.is_storage and getattr(cell, "reserved_by", None) is None:
                    boxes.append((r, c))
        return boxes

    def cfp_and_assign(self):
        boxes = self.find_open_boxes()   

        for (br, bc) in boxes:          
            cell = self.wh.cells[br][bc]
            if getattr(cell, "reserved_by", None) is not None:
                continue

            proposals = []
            for bot in self.wh.robots:
                prop = bot.make_proposal((br, bc), self.wh)
                if prop is not None and prop['available']:
                    proposals.append(prop)
                    self.log(f"[Robot {bot.id}] PROPOSE dist={prop['distance']}")

            if not proposals:
                self.log(f"[MonitoringAgent] No proposals available for {(br,bc)}")
                continue

            proposals.sort(key=lambda p: (p['distance'], p['agent_id']))
            winner = proposals[0]
            winner_agent = next(a for a in self.wh.robots if a.id == winner['agent_id'])

            cell.reserved_by = winner_agent.id
            cell.reserved_by_ticks = 0

            approach_pos = winner.get('approach', None)
            if approach_pos is None:
                _, approach_pos = self.wh.find_reachable_adjacent(
                    (winner_agent.row, winner_agent.col),
                    (br, bc)
                )

            winner_agent.assign_task('pickup', (br, bc), self.wh, approach_pos=approach_pos)

            self.log(f"[MonitoringAgent] ACCEPT -> Robot {winner_agent.id} for {(br,bc)} via {approach_pos}")
