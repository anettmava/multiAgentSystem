import random
from sensor_module import SensorModule

class Robot:
    def __init__(self, id_):
        self.id = id_
        self.x = None
        self.y = None
        self.carrying = False
        self.movementCount = 0
        self.sensor = SensorModule(self)
        self.assigned_task = None  
        self.path = None
        self.path_step = 0
        self.moves = 0

    @property
    def row(self):
        return self.x

    @row.setter
    def row(self, v):
        self.x = v

    @property
    def col(self):
        return self.y

    @col.setter
    def col(self, v):
        self.y = v

    def move(self, direction, warehouse):
        if isinstance(direction, tuple):
            dr, dc = direction
        else:
            dirs = {'UP':(-1,0),'DOWN':(1,0),'LEFT':(0,-1),'RIGHT':(0,1)}
            dr, dc = dirs.get(direction, (0,0))
        nr, nc = self.row + dr, self.col + dc
        ok = warehouse.move_robot(self, nr, nc)
        if ok:
            self.movementCount += 1
            self.moves += 1
        return ok

    def pickUp(self, warehouse):
        if self.assigned_task and self.assigned_task[0] == 'pickup':
            tr, tc = self.assigned_task[1]
            if abs(tr - self.row) + abs(tc - self.col) == 1:
                box = warehouse.grid[tr][tc].pop_box()
                if box is not None:
                    self.carrying = True
                    self.assigned_task = None
                    return True
        return False

    def dropOff(self, warehouse):
        if self.assigned_task and self.assigned_task[0] == 'deliver':
            tr, tc = self.assigned_task[1]
            if abs(tr - self.row) + abs(tc - self.col) == 1:
                from box import Box
                b = Box()
                pushed = warehouse.grid[tr][tc].push_box(b)
                if pushed:
                    self.carrying = False
                    self.assigned_task = None
                    return True
        return False

    def scan(self, warehouse):
        return self.sensor.scanEnvironment(warehouse)

    def decideAction(self, warehouse):
        if self.assigned_task is None:
            self._relocate_if_blocking(warehouse)
            return None
        return self.assigned_task

    def executeAction(self, warehouse, log_fn=None):
        if self.assigned_task is None:
            return

        if self.path is None:
            self.path = warehouse.astar((self.row,self.col), self.assigned_task[1])
            self.path_step = 0
            if self.path is None:
                self.assigned_task = None
                return

        if self.path_step + 1 < len(self.path):
            nr, nc = self.path[self.path_step + 1]
            moved = warehouse.move_robot(self, nr, nc)
            if moved:
                self.path_step += 1
            else:
                self.path = None
                self.path_step = 0
            return

        ttype, target = self.assigned_task
        if ttype == 'pickup':
            tr, tc = target
            if abs(tr - self.row) + abs(tc - self.col) == 1:
                box = warehouse.grid[tr][tc].pop_box()
                if box:
                    self.carrying = True
                    if log_fn:
                        log_fn(f"[Robot {self.id}] picked up from {(tr,tc)}")
                    self.assigned_task = None
                    self.path = None
                    return
                else:
                    self.assigned_task = None
                    self.path = None
                    return
        elif ttype == 'deliver':
            tr, tc = target
            if abs(tr - self.row) + abs(tc - self.col) == 1:
                from box import Box
                b = Box()
                pushed = warehouse.grid[tr][tc].push_box(b)
                if pushed:
                    self.carrying = False
                    if log_fn:
                        log_fn(f"[Robot {self.id}] delivered to {(tr,tc)}")
                    self.assigned_task = None
                    self.path = None
                else:
                    self.assigned_task = None
                    self.path = None
                return

    def _relocate_if_blocking(self, warehouse):
        cell = warehouse.grid[self.row][self.col]
        if cell.is_storage:
            self._move_to_safe_spot(warehouse)
            return
        for (sr, sc) in warehouse.storage_positions:
            if abs(self.row - sr) + abs(self.col - sc) == 1:
                self._move_to_safe_spot(warehouse)
                return

    def _move_to_safe_spot(self, warehouse):
        neigh = [(1,0),(-1,0),(0,1),(0,-1)]
        random.shuffle(neigh)
        for dr, dc in neigh:
            nr, nc = self.row+dr, self.col+dc
            if warehouse.in_bounds(nr, nc) and warehouse.grid[nr][nc].robot is None and not warehouse.grid[nr][nc].is_storage:
                warehouse.move_robot(self, nr, nc)
                return
