from boxstack import BoxStack

class Cell:
    """Cell follows UML: coordinates + stack + robot reference; plus flags used by sim."""

    def __init__(self, row, col, max_stack=BoxStack.MAX_HEIGHT):
        self.row = row
        self.col = col
        self.stack = BoxStack(max_stack) 
        self.robot = None                 
        self.is_storage = False           
        self.reserved_by = None           

    def isEmpty(self):
        return (not self.is_storage) and (self.stack.is_empty())

    def hasRobot(self):
        return self.robot is not None

    def hasStack(self):
        return self.stack.height() > 0

    def isWall(self):
        return False  # we don't use walls in current sim

    # helper wrappers to interact with BoxStack
    def stack_height(self):
        return self.stack.height()

    def can_receive(self):
        return self.stack.can_push()

    def push_box(self, n=1):
        return self.stack.push(n)

    def pop_box(self, n=1):
        return self.stack.pop(n)
