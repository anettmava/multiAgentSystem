class CellReading:
    def __init__(self, isWall=False, robotPresent=False, stackHeight=0, isFree=True):
        self.isWall = isWall
        self.robotPresent = robotPresent
        self.stackHeight = stackHeight
        self.isFree = isFree

    def __repr__(self):
        return f"CellReading(wall={self.isWall}, robot={self.robotPresent}, height={self.stackHeight}, free={self.isFree})"
