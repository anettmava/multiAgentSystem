
import random
import heapq
from cell import Cell

class Warehouse:
    """Grid world with cells, storage positions and A* pathfinding."""

    def __init__(self, width, height, num_boxes, storage_positions=None):
        self.width = width
        self.height = height
 
        self.cells = [[Cell(r, c) for c in range(width)] for r in range(height)]

        self.num_boxes = num_boxes
     
        num_storage = (num_boxes // Cell(0,0).stack.max_height) if num_boxes > 0 else 0

        if storage_positions is None:
            self.storage_positions = self._compute_storage_positions(num_storage)
        else:
            self.storage_positions = storage_positions

        for (r,c) in self.storage_positions:
            if self.in_bounds(r,c):
                self.cells[r][c].is_storage = True

        self._place_random_boxes(self.num_boxes)

        self.robots = []

    def _compute_storage_positions(self, count):
        if count <= 0:
            return []
        total = self.width * self.height
        pos = []
        for i in range(count):
            idx = int(((i + 1) * total) / (count + 1))
            rr = idx // self.width
            cc = idx % self.width
            pos.append((rr, cc))
        seen = set()
        uniq = []
        cur = 0
        for p in pos:
            if p not in seen:
                seen.add(p); uniq.append(p)
        while len(uniq) < count:
            rr = cur // self.width; cc = cur % self.width
            if (rr,cc) not in seen:
                seen.add((rr,cc)); uniq.append((rr,cc))
            cur += 1
        return uniq

    def _place_random_boxes(self, k):
        placed = 0
        attempts = 0
        max_attempts = max(1000, k * 200)
        while placed < k and attempts < max_attempts:
            attempts += 1
            r = random.randrange(0, self.height)
            c = random.randrange(0, self.width)
            if (r, c) in self.storage_positions:
                continue
            cell = self.cells[r][c]
            if cell.hasStack():
                continue
            if cell.robot is not None:
                continue
            pushed = cell.push_box(1)
            if pushed > 0:
                placed += pushed
        if placed < k:
            print(f"[warning] placed {placed}/{k} boxes")

    def in_bounds(self, r, c):
        return 0 <= r < self.height and 0 <= c < self.width

    def add_robot(self, robot):
        attempts = 0
        while attempts < 10000:
            attempts += 1
            r = random.randrange(0, self.height)
            c = random.randrange(0, self.width)
            if (r, c) in self.storage_positions:
                continue
            cell = self.cells[r][c]
            if cell.hasStack():
                continue
            if cell.robot is None:
                cell.robot = robot
                robot.row = r
                robot.col = c
                self.robots.append(robot)
                return True
        return False

    def move_robot(self, robot, nr, nc):
        if not self.in_bounds(nr, nc):
            return False
        target = self.cells[nr][nc]
        if target.robot is not None:
            return False
        self.cells[robot.row][robot.col].robot = None
        robot.row, robot.col = nr, nc
        target.robot = robot
        return True

    def total_missing_to_complete_stacks(self):
        missing = 0
        for (r,c) in self.storage_positions:
            missing += (self.cells[r][c].stack.max_height - self.cells[r][c].stack_height())
        return missing

    def astar(self, start, goal):
        sr, sc = start
        gr, gc = goal
        if not self.in_bounds(gr, gc) or not self.in_bounds(sr, sc):
            return None

        def h(a, b):
            return abs(a[0]-b[0]) + abs(a[1]-b[1])

        open_heap = []
        heapq = __import__("heapq")
        heapq.heappush(open_heap, (h(start, goal), 0, start))
        parents = {start: None}
        gscore = {start: 0}
        closed = set()

        while open_heap:
            f, g, node = heapq.heappop(open_heap)
            if node in closed:
                continue
            if node == goal:
                path = []
                cur = node
                while cur is not None:
                    path.append(cur)
                    cur = parents[cur]
                return list(reversed(path))
            closed.add(node)
            r, c = node
            for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                nr, nc = r + dr, c + dc
                if not self.in_bounds(nr, nc):
                    continue
                if self.cells[nr][nc].robot is not None and (nr, nc) != goal:
                    continue
                tentative_g = g + 1
                neighbor = (nr, nc)
                if neighbor in closed:
                    continue
                if tentative_g < gscore.get(neighbor, 1e9):
                    parents[neighbor] = node
                    gscore[neighbor] = tentative_g
                    heapq.heappush(open_heap, (tentative_g + h(neighbor, goal), tentative_g, neighbor))
        return None
    def get_adjacent_positions(self, pos):
        r, c = pos
        adj = []
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            nr, nc = r+dr, c+dc
            if self.in_bounds(nr, nc):
                adj.append((nr, nc))
        return adj

    def find_reachable_adjacent(self, start, box_pos):
        """
        Return a tuple (path, approach_pos) where 'path' is the A* path from start
        to an *adjacent* cell to box_pos, AND approach_pos is that adjacent cell.
        If multiple adjacents reachable, choose the one with shortest path.
        Return (None, None) if none reachable.
        """
        candidates = self.get_adjacent_positions(box_pos)
        best_path = None
        best_target = None
        best_len = 10**9
        for cand in candidates:
          
            if self.cells[cand[0]][cand[1]].robot is not None:
                continue
            path = self.astar(start, cand)
            if path is None:
                continue
            L = len(path) - 1
            if L < best_len:
                best_len = L
                best_path = path
                best_target = cand
        if best_path is None:
            return (None, None)
        return (best_path, best_target)
    def all_storage_full(self):
        for (r, c) in self.storage_positions:
            if self.cells[r][c].stack.height() < 5:
                return False
        return True
