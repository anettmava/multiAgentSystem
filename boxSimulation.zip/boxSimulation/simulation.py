import time
from warehouse import Warehouse
from robot_agent import ResponseAgent
from monitoring_agent import MonitoringAgent

MAX_RUNTIME_SEC = 60      
MAX_STEPS = 280         

class Simulation:
    def __init__(self, width=18, height=15, num_boxes=50, num_robots=5, storage_positions=None, log_fn=None):
        self.wh = Warehouse(width, height, num_boxes, storage_positions)
        self.log = log_fn or (lambda s: None)

        self.robots = []
        for i in range(num_robots):
            r = ResponseAgent(i)
            ok = self.wh.add_robot(r)
            if not ok:
                raise RuntimeError("Couldn't place robot")
            self.robots.append(r)

        self.monitor = MonitoringAgent(self.wh, log_fn=self.log)

        self.steps = 0
        self.total_moves = 0
        self.ended = False

        self.start_time = time.time()

    def step(self):
        if self.ended:
            return True

        elapsed = time.time() - self.start_time
        if elapsed >= MAX_RUNTIME_SEC:
            self.ended = True
            self.log(f"[Simulation] Finished by TIME LIMIT ({MAX_RUNTIME_SEC}s)")
            return True

        if self.steps >= MAX_STEPS:
            self.ended = True
            self.log(f"[Simulation] Finished by STEP LIMIT ({MAX_STEPS} steps)")
            return True

        self.monitor.cfp_and_assign()

        for bot in self.wh.robots:
            if bot.carrying and bot.assigned_task is None:
                best = None
                best_d = 1e9
                for sp in self.wh.storage_positions:
                    cell = self.wh.cells[sp[0]][sp[1]]
                    if cell.can_receive():
                        path = self.wh.astar((bot.row, bot.col), sp)
                        if path is not None and len(path)-1 < best_d:
                            best = sp
                            best_d = len(path)-1
                if best is not None:
                    bot.assign_task('deliver', best, self.wh)
                    self.log(f"[MonitoringAgent] Assigned deliver -> Robot {bot.id} -> {best}")

        for bot in self.wh.robots:
            bot.step(self.wh, log_fn=self.log)

        self.steps += 1
        self.total_moves = sum(b.moves for b in self.wh.robots)

        missing = self.wh.total_missing_to_complete_stacks()
        if missing == 0:
            self.ended = True
            self.log(f"[Simulation] Finished CLEANLY in {self.steps} steps, moves {self.total_moves}")
            return True

        return False
