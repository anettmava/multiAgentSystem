class Box:
    """Optional Box object (not used if BoxStack works by counts)."""
    _next_id = 1

    def __init__(self):
        self.id = Box._next_id
        Box._next_id += 1

    def __repr__(self):
        return f"Box({self.id})"
