class BoxStack:

    MAX_HEIGHT = 5

    def __init__(self, max_height=None):
        self.max_height = max_height if max_height is not None else BoxStack.MAX_HEIGHT
        self._count = 0

    def push(self, n=1):
        pushed = 0
        for _ in range(n):
            if self._count < self.max_height:
                self._count += 1
                pushed += 1
            else:
                break
        return pushed

    def pop(self, n=1):
        popped = 0
        for _ in range(n):
            if self._count > 0:
                self._count -= 1
                popped += 1
            else:
                break
        return popped

    def height(self):
        return self._count

    def is_full(self):
        return self._count >= self.max_height

    def is_empty(self):
        return self._count == 0

    def can_push(self):
        return self._count < self.max_height
