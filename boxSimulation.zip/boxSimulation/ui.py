import tkinter as tk
from tkinter import ttk, scrolledtext
from boxstack import BoxStack

CELL_PIX = 32

class WarehouseUI:
    def __init__(self, root, sim, tick_ms=220):
        self.root = root
        self.sim = sim
        self.tick_ms = tick_ms
        self.running = False
        self._after_id = None

        root.title("Warehouse - UML Hybrid + CNP + A*")

        top = ttk.Frame(root)
        top.pack(side="top", fill="x", padx=6, pady=6)
        self.btn_start = ttk.Button(top, text="Start", command=self.start)
        self.btn_pause = ttk.Button(top, text="Pause", command=self.pause)
        self.btn_step = ttk.Button(top, text="Step", command=self.step_once)
        self.btn_reset = ttk.Button(top, text="Reset", command=self.reset)
        for b in (self.btn_start, self.btn_pause, self.btn_step, self.btn_reset):
            b.pack(side="left", padx=4)

        ttk.Label(top, text="Speed ms/step:").pack(side="left", padx=(12,2))
        self.speed_var = tk.IntVar(value=tick_ms)
        self.speed_spin = tk.Spinbox(top, from_=50, to=2000, increment=50, textvariable=self.speed_var, width=7, command=self.update_speed)
        self.speed_spin.pack(side="left")

        self.lbl_info = ttk.Label(top, text="Steps:0 Moves:0 Missing:0")
        self.lbl_info.pack(side="left", padx=12)

        main = ttk.Frame(root)
        main.pack(fill="both", expand=True, padx=6, pady=6)

        w_px = self.sim.wh.width * CELL_PIX
        h_px = self.sim.wh.height * CELL_PIX
        self.canvas = tk.Canvas(main, width=w_px, height=h_px, bg="white")
        self.canvas.pack(side="left")

        self.logbox = scrolledtext.ScrolledText(main, width=40, height=30, state='disabled')
        self.logbox.pack(side="right", fill="y")

     
        self.sim.log = self.log

        self.robot_colors = ["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b"]
        self.draw()

    def log(self, s):
        self.logbox.configure(state='normal')
        self.logbox.insert('end', s + "\n")
        self.logbox.see('end')
        self.logbox.configure(state='disabled')

    def update_speed(self):
        try:
            self.tick_ms = int(self.speed_var.get())
        except: pass

    def start(self):
        if self.sim.ended:
            return
        if not self.running:
            self.running = True
            self._loop()

    def pause(self):
        if self.running:
            self.running = False
            if self._after_id:
                self.root.after_cancel(self._after_id)
                self._after_id = None

    def step_once(self):
        finished = self.sim.step()
        self.draw()
        self.update_info()
        if finished:
            self.log(f"[UI] Finished in {self.sim.steps} steps, moves {self.sim.total_moves}")

    def reset(self):
        
        w = self.sim.wh.width; h = self.sim.wh.height
        boxes = self.sim.wh.num_boxes
        robots = len(self.sim.wh.robots)
        storage_positions = self.sim.wh.storage_positions
        self.sim = type(self.sim)(w, h, boxes, robots, storage_positions, log_fn=self.log)
        self.draw(); self.update_info()

    def _loop(self):
        if not self.running:
            return
        finished = self.sim.step()
        self.draw()
        self.update_info()
        if finished:
            self.log(f"[UI] Finished in {self.sim.steps} steps, moves {self.sim.total_moves}")
            self.running = False
            return
        self._after_id = self.root.after(self.tick_ms, self._loop)

    def update_info(self):
        missing = self.sim.wh.total_missing_to_complete_stacks()
        self.lbl_info.config(text=f"Steps:{self.sim.steps} Moves:{self.sim.total_moves} Missing:{missing}")

    def draw(self):
        self.canvas.delete("all")
        wh = self.sim.wh
        cs = CELL_PIX
        for r in range(wh.height):
            for c in range(wh.width):
                x0 = c*cs; y0 = r*cs; x1 = x0+cs; y1 = y0+cs
                cell = wh.cells[r][c]
                bg = "#ddffdd" if (r,c) in wh.storage_positions else "#f8f8f8"
                self.canvas.create_rectangle(x0,y0,x1,y1, fill=bg, outline="#bbb")
                if cell.hasStack():
                    h = cell.stack_height()
                    block_h = cs / BoxStack.MAX_HEIGHT
                    for i in range(h):
                        by0 = y1 - (i+1)*block_h
                        by1 = y1 - i*block_h
                        self.canvas.create_rectangle(x0+2, by0+2, x1-2, by1-2, fill="#8B4513")
                    self.canvas.create_text(x1-10, y0+10, text=str(cell.stack_height()), fill="white")
                if getattr(cell, "reserved_by", None) is not None:
                    self.canvas.create_text(x0+10, y0+10, text=f"R{cell.reserved_by}", fill="navy")
        # robots
        for bot in self.sim.wh.robots:
            rx = bot.col * cs; ry = bot.row * cs
            pad = cs*0.15
            color = self.robot_colors[bot.id % len(self.robot_colors)]
            self.canvas.create_oval(rx+pad, ry+pad, rx+cs-pad, ry+cs-pad, fill=color, outline="black")
            self.canvas.create_text(rx+cs/2, ry+cs/2, text=str(bot.id+1), fill="white")
            if bot.carrying:
                s = cs*0.18; cx = rx+cs/2; cy = ry+s
                self.canvas.create_rectangle(cx-s/2, cy-s/2, cx+s/2, cy+s/2, fill="gold")
